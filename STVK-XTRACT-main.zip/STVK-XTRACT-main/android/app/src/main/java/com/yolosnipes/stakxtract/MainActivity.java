package com.yolosnipes.stakxtract;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
